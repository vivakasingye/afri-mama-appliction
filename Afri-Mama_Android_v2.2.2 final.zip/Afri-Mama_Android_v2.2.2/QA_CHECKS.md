# Afri-Mama v2.2.2 QA checks

- App name remains Afri-Mama
- Version updated to 2.2.2 (versionCode 10)
- Splash updated to show logo first, then Afri-Mama text below
- Startup flow simplified to avoid long blocking splash behavior
- Initial timeout reduced to 15 seconds for quicker recovery on weak networks
- Existing WebView URL preserved
