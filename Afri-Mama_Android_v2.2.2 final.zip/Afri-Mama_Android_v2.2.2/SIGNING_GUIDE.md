# Afri-Mama — original signing keystore restored

**Important:** This project includes the exact `MAMA.JKS` keystore from the original user-supplied `MamaCare_Uganda_WebView_Final_v3(1).zip` archive. It was restored without changing its bytes. Do not generate a new keystore if you want to retain the same upload/signing identity. Keep a safe independent backup of this original file and do not share it publicly.

## Signing in Android Studio

1. Open this project in Android Studio and allow Gradle sync to finish.
2. Go to **Build → Generate Signed Bundle / APK**.
3. Select **Android App Bundle** for Play Store, or APK for an installable test build.
4. Select **Choose existing** and locate `MAMA.JKS` in the root of this project.
5. The original keystore has one alias: `key0`. Enter **your original keystore password and key password**. Neither password was present in the original source ZIP, and we did not create or change one.
6. Select release and finish the signing wizard. Use the correct existing Play Console signing/upload key.

The Gradle release configuration is unchanged and does **not** embed passwords in source files. The keystore itself is password-protected and cannot be signed with until the correct original passwords are supplied.

If Google Play reports an unexpected upload certificate, check the Play Console's App integrity page and compare the upload-key fingerprint before publishing.
