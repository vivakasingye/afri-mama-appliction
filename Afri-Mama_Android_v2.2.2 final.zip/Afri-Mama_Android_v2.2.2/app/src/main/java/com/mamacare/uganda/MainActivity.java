package com.mamacare.uganda;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.window.OnBackInvokedDispatcher;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * A minimal, ad-free native host for Afri-Mama's existing responsive web app.
 * No native app bar, bottom navigation, drawer, or website-address setup screen.
 */
public final class MainActivity extends Activity {
    private static final int CHOOSE_FILE = 301;
    private static final int LOCATION_PERMISSION = 302;
    private static final int MEDIA_PERMISSION = 303;
    private static final int STORAGE_PERMISSION = 304;
    private static final long FIRST_LOAD_TIMEOUT_MS = 15000;

    private boolean firstPageVisible;
    private boolean mainFrameFailed;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Runnable startupTimeout = () -> {
        if (!firstPageVisible && !isFinishing() && !isDestroyed()) {
            showError(getString(R.string.connection_timeout));
        }
    };

    private WebView webView;
    private FrameLayout splashOverlay;
    private LinearLayout errorPanel;
    private TextView errorDescription;
    private ProgressBar topProgress;
    private FrameLayout decorContent;
    private String appUrl;


    private ValueCallback<Uri[]> fileChooser;
    private GeolocationPermissions.Callback geoCallback;
    private String geoOrigin;
    private PermissionRequest mediaRequest;
    private DownloadRequest pendingDownload;

    private View fullScreenVideo;
    private WebChromeClient.CustomViewCallback fullScreenCallback;

    @Override
    @SuppressLint("SetJavaScriptEnabled")
    protected void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        setContentView(R.layout.activity_main);

        appUrl = getString(R.string.website_url);
        webView = findViewById(R.id.web_view);
        splashOverlay = findViewById(R.id.splash_overlay);
        errorPanel = findViewById(R.id.error_panel);
        errorDescription = findViewById(R.id.error_description);
        topProgress = findViewById(R.id.top_progress);
        decorContent = findViewById(android.R.id.content);
        findViewById(R.id.retry_button).setOnClickListener(v -> retry());

        // API 35+ enforces edge-to-edge. Respect status, navigation, and keyboard insets.
        if (Build.VERSION.SDK_INT >= 35) {
            View root = findViewById(R.id.root);
            root.setOnApplyWindowInsetsListener((view, windowInsets) -> {
                android.graphics.Insets bars = windowInsets.getInsets(WindowInsets.Type.systemBars());
                android.graphics.Insets keyboard = windowInsets.getInsets(WindowInsets.Type.ime());
                view.setPadding(bars.left, bars.top, bars.right,
                        Math.max(bars.bottom, keyboard.bottom));
                return windowInsets;
            });
            root.requestApplyInsets();
        }

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);  // Android document picker content URIs
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setSupportZoom(false);
        if (Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        // OAuth/payment iframes sometimes need their own cookie storage.
        cookies.setAcceptThirdPartyCookies(webView, true);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);

        webView.setWebViewClient(new CareWebViewClient());
        webView.setWebChromeClient(new CareChromeClient());
        webView.setDownloadListener(new CareDownloadListener());

        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::handleBack);
        }

        if (savedState != null && webView.restoreState(savedState) != null) {
            firstPageVisible = true;
            splashOverlay.setVisibility(View.GONE);
            errorPanel.setVisibility(View.GONE);
        } else {
            // Show a single branded Afri-Mama splash overlay while the website loads.
            splashOverlay.setVisibility(View.VISIBLE);
            startLoadingHome();
        }
    }

    private void startLoadingHome() {
        mainFrameFailed = false;
        mainHandler.removeCallbacks(startupTimeout);
        mainHandler.postDelayed(startupTimeout, FIRST_LOAD_TIMEOUT_MS);
        if (!hasConnectivity()) {
            showError(getString(R.string.offline_message));
        } else {
            webView.loadUrl(appUrl);
        }
    }

    private boolean hasConnectivity() {
        ConnectivityManager connectivity =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity == null) return true;
        Network active = connectivity.getActiveNetwork();
        NetworkCapabilities capabilities = connectivity.getNetworkCapabilities(active);
        // A local captive portal may report internet capability but fail to load;
        // the main-frame error and timeout handlers cover that case.
        return capabilities != null &&
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }

    private void showWebsite() {
        mainHandler.removeCallbacks(startupTimeout);
        if (firstPageVisible || mainFrameFailed || isFinishing()) return;
        firstPageVisible = true;
        topProgress.setVisibility(View.GONE);
        splashOverlay.animate().alpha(0f).setDuration(300).withEndAction(() -> {
            splashOverlay.setVisibility(View.GONE);
            splashOverlay.setAlpha(1f);
        }).start();
    }

    private void showError(String detail) {
        mainHandler.removeCallbacks(startupTimeout);
        mainFrameFailed = true;
        splashOverlay.animate().cancel();
        splashOverlay.setVisibility(View.GONE);
        topProgress.setVisibility(View.GONE);
        errorDescription.setText(detail);
        errorPanel.setVisibility(View.VISIBLE);
    }

    private void retry() {
        errorPanel.setVisibility(View.GONE);
        mainFrameFailed = false;
        if (!firstPageVisible) {
            splashOverlay.setAlpha(1f);
            splashOverlay.setVisibility(View.VISIBLE);
            topProgress.setProgress(0);
            startLoadingHome();
        } else if (hasConnectivity()) {
            if (webView.getUrl() == null) webView.loadUrl(appUrl);
            else webView.reload();
        } else {
            showError(getString(R.string.offline_message));
        }
    }

    @Override
    public void onBackPressed() {
        handleBack();
    }

    private void handleBack() {
        if (fullScreenVideo != null) {
            closeFullScreenVideo();
        } else if (webView.canGoBack()) {
            errorPanel.setVisibility(View.GONE);
            webView.goBack();
        } else {
            finish();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onPause() {
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onDestroy() {
        mainHandler.removeCallbacksAndMessages(null);
        if (fileChooser != null) {
            fileChooser.onReceiveValue(null);
            fileChooser = null;
        }
        if (mediaRequest != null) {
            mediaRequest.deny();
            mediaRequest = null;
        }
        if (geoCallback != null) {
            geoCallback.invoke(geoOrigin, false, false);
            geoCallback = null;
        }
        if (webView != null) {
            if (webView.getParent() instanceof ViewGroup) {
                ((ViewGroup) webView.getParent()).removeView(webView);
            }
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
        }
        super.onDestroy();
    }

    private static boolean isHttps(String url) {
        try {
            URI uri = URI.create(url);
            return "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost() != null;
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean isAfriMamaOrigin(String url) {
        try {
            URI requested = URI.create(url);
            URI expected = URI.create(appUrl);
            return "https".equalsIgnoreCase(requested.getScheme())
                    && requested.getHost() != null
                    && expected.getHost() != null
                    && requested.getHost().toLowerCase(Locale.ROOT)
                    .equals(expected.getHost().toLowerCase(Locale.ROOT));
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean openNonWebLink(Uri uri) {
        String scheme = uri.getScheme();
        if (scheme == null) return true;
        if ("https".equalsIgnoreCase(scheme)) return false;
        if ("intent".equalsIgnoreCase(scheme)) {
            try {
                Intent intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                intent.setComponent(null);
                intent.setSelector(null);
                try {
                    startActivity(intent);
                } catch (Exception e) {
                    String fallback = intent.getStringExtra("browser_fallback_url");
                    if (fallback != null && isHttps(fallback)) webView.loadUrl(fallback);
                    else Toast.makeText(this, R.string.no_app, Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, R.string.no_app, Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        if ("tel".equalsIgnoreCase(scheme) || "mailto".equalsIgnoreCase(scheme)
                || "sms".equalsIgnoreCase(scheme) || "geo".equalsIgnoreCase(scheme)
                || "market".equalsIgnoreCase(scheme) || "whatsapp".equalsIgnoreCase(scheme)
                || "upi".equalsIgnoreCase(scheme)) {
            try {
                Intent external = new Intent(Intent.ACTION_VIEW, uri);
                external.addCategory(Intent.CATEGORY_BROWSABLE);
                startActivity(external);
            } catch (ActivityNotFoundException | SecurityException ignored) {
                Toast.makeText(this, R.string.no_app, Toast.LENGTH_SHORT).show();
            }
        }
        // Reject file://, data:, javascript:, http:// and unknown schemes.
        return true;
    }

    private final class CareWebViewClient extends WebViewClient {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            if (mainFrameFailed) return;
            if (firstPageVisible) {
                topProgress.setProgress(3);
                topProgress.setVisibility(View.VISIBLE);
            }
        }

        @Override
        public void onPageCommitVisible(WebView view, String url) {
            if (!mainFrameFailed) showWebsite();
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            CookieManager.getInstance().flush();
            topProgress.setVisibility(View.GONE);
            // Some device WebView versions don't call onPageCommitVisible.
            if (!mainFrameFailed) showWebsite();
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return openNonWebLink(request.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return openNonWebLink(Uri.parse(url));
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request,
                                    WebResourceError error) {
            if (request.isForMainFrame()) showError(getString(R.string.network_error));
        }

        @Override
        public void onReceivedHttpError(WebView view, WebResourceRequest request,
                                        WebResourceResponse response) {
            // 401/403 are for the website to handle; display branded retry on server failure.
            if (request.isForMainFrame() && response.getStatusCode() >= 500) {
                showError(getString(R.string.server_error));
            }
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.cancel();
            showError(getString(R.string.certificate_error));
        }
    }

    private final class CareChromeClient extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            if (!firstPageVisible || mainFrameFailed) return;
            topProgress.setProgress(newProgress);
            if (newProgress == 100) topProgress.setVisibility(View.GONE);
            else topProgress.setVisibility(View.VISIBLE);
        }

        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                         FileChooserParams chooserParams) {
            if (fileChooser != null) fileChooser.onReceiveValue(null);
            fileChooser = callback;
            try {
                Intent intent = chooserParams.createIntent();
                startActivityForResult(intent, CHOOSE_FILE);
            } catch (Exception e) {
                fileChooser.onReceiveValue(null);
                fileChooser = null;
                Toast.makeText(MainActivity.this, R.string.no_app, Toast.LENGTH_SHORT).show();
            }
            return true;
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin,
                                                       GeolocationPermissions.Callback callback) {
            if (!isAfriMamaOrigin(origin)) {
                callback.invoke(origin, false, false);
                return;
            }
            if (hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                    || hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
                callback.invoke(origin, true, false);
            } else {
                if (geoCallback != null) geoCallback.invoke(geoOrigin, false, false);
                geoOrigin = origin;
                geoCallback = callback;
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION);
            }
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            runOnUiThread(() -> requestMedia(request));
        }

        @Override
        public void onPermissionRequestCanceled(PermissionRequest request) {
            if (mediaRequest == request) mediaRequest = null;
        }

        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog,
                                      boolean isUserGesture, Message resultMsg) {
            if (!isUserGesture) return false;
            // target="_blank" links navigate within the web app; no native popup/menu.
            WebView popup = new WebView(MainActivity.this);
            popup.setWebViewClient(new WebViewClient() {
                private boolean moved = false;

                private void handle(String url) {
                    if (moved) return;
                    moved = true;
                    Uri uri = Uri.parse(url);
                    if (!openNonWebLink(uri)) webView.loadUrl(url);
                    popup.post(popup::destroy);
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                    handle(req.getUrl().toString());
                    return true;
                }

                @Override
                public void onPageStarted(WebView v, String url, Bitmap favicon) {
                    if (!"about:blank".equals(url)) handle(url);
                }
            });
            WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
            transport.setWebView(popup);
            resultMsg.sendToTarget();
            return true;
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (fullScreenVideo != null) {
                callback.onCustomViewHidden();
                return;
            }
            fullScreenVideo = view;
            fullScreenCallback = callback;
            decorContent.addView(view, new FrameLayout.LayoutParams(-1, -1));
            findViewById(R.id.root).setVisibility(View.INVISIBLE);
            view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }

        @Override
        public void onHideCustomView() {
            closeFullScreenVideo();
        }
    }

    private void closeFullScreenVideo() {
        if (fullScreenVideo == null) return;
        decorContent.removeView(fullScreenVideo);
        fullScreenVideo = null;
        findViewById(R.id.root).setVisibility(View.VISIBLE);
        if (fullScreenCallback != null) fullScreenCallback.onCustomViewHidden();
        fullScreenCallback = null;
    }

    private boolean hasPermission(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestMedia(PermissionRequest request) {
        if (!isAfriMamaOrigin(request.getOrigin().toString())) {
            request.deny();
            return;
        }
        List<String> supported = new ArrayList<>();
        List<String> pending = new ArrayList<>();
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                supported.add(resource);
                if (!hasPermission(Manifest.permission.CAMERA)) pending.add(Manifest.permission.CAMERA);
            } else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                supported.add(resource);
                if (!hasPermission(Manifest.permission.RECORD_AUDIO))
                    pending.add(Manifest.permission.RECORD_AUDIO);
            }
        }
        if (supported.isEmpty()) {
            request.deny();
        } else if (pending.isEmpty()) {
            request.grant(supported.toArray(new String[0]));
        } else {
            if (mediaRequest != null) mediaRequest.deny();
            mediaRequest = request;
            requestPermissions(pending.toArray(new String[0]), MEDIA_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == LOCATION_PERMISSION && geoCallback != null) {
            boolean allowed = hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    || hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION);
            geoCallback.invoke(geoOrigin, allowed, false);
            geoCallback = null;
            geoOrigin = null;
        } else if (code == MEDIA_PERMISSION && mediaRequest != null) {
            List<String> allowed = new ArrayList<>();
            for (String resource : mediaRequest.getResources()) {
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)
                        && hasPermission(Manifest.permission.CAMERA)) allowed.add(resource);
                else if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)
                        && hasPermission(Manifest.permission.RECORD_AUDIO)) allowed.add(resource);
            }
            if (allowed.isEmpty() || !isAfriMamaOrigin(mediaRequest.getOrigin().toString())) {
                mediaRequest.deny();
            } else {
                mediaRequest.grant(allowed.toArray(new String[0]));
            }
            mediaRequest = null;
        } else if (code == STORAGE_PERMISSION && pendingDownload != null) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                enqueueDownload(pendingDownload);
            } else {
                Toast.makeText(this, R.string.download_error, Toast.LENGTH_SHORT).show();
            }
            pendingDownload = null;
        }
    }

    @Override
    protected void onActivityResult(int code, int result, Intent data) {
        super.onActivityResult(code, result, data);
        if (code == CHOOSE_FILE && fileChooser != null) {
            fileChooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileChooser = null;
        }
    }

    private static final class DownloadRequest {
        final String url;
        final String userAgent;
        final String disposition;
        final String mime;

        DownloadRequest(String u, String agent, String disp, String contentType) {
            url = u;
            userAgent = agent;
            disposition = disp;
            mime = contentType;
        }
    }

    private final class CareDownloadListener implements DownloadListener {
        @Override
        public void onDownloadStart(String url, String agent, String disposition,
                                    String mime, long size) {
            if (!isHttps(url)) {
                Toast.makeText(MainActivity.this, R.string.download_error, Toast.LENGTH_SHORT).show();
                return;
            }
            DownloadRequest download = new DownloadRequest(url, agent, disposition, mime);
            if (Build.VERSION.SDK_INT <= 28 &&
                    !hasPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                pendingDownload = download;
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        STORAGE_PERMISSION);
            } else {
                enqueueDownload(download);
            }
        }
    }

    private void enqueueDownload(DownloadRequest download) {
        try {
            String filename = URLUtil.guessFileName(download.url, download.disposition, download.mime)
                    .replaceAll("[^a-zA-Z0-9._() -]", "_");
            if (filename.length() > 120) filename = filename.substring(filename.length() - 120);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(download.url));
            request.setTitle(filename);
            if (download.mime != null) request.setMimeType(download.mime);
            if (download.userAgent != null) request.addRequestHeader("User-Agent", download.userAgent);
            String sessionCookie = CookieManager.getInstance().getCookie(download.url);
            if (sessionCookie != null) request.addRequestHeader("Cookie", sessionCookie);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
            DownloadManager service = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (service == null) throw new IllegalStateException("Download service missing");
            service.enqueue(request);
            Toast.makeText(this, R.string.download_started, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, R.string.download_error, Toast.LENGTH_LONG).show();
        }
    }
}
