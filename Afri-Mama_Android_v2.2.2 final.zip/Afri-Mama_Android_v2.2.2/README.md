# Afri-Mama — Android WebView v2.2.2 (single-splash fix)

This update corrects the **double splash on Android 12 and newer**.

## What changed

- **Android 12+ (API 31+):** only the OS-provided splash is shown (Afri-Mama icon on white). The duplicate in-app overlay is disabled and the existing system splash stays until the first WebView page is ready.
- **Android 7–11 (API 24–30):** the single in-app logo on white is shown while the first page loads; the Android 12 system splash does not apply.
- On a page-load error or timeout, the opening screen is released and the existing retry screen appears; a retry does not show another logo on Android 12+.
- App name **Afri-Mama**, original app logo and logo-only white launch appearance unchanged.
- Updated version to **2.2.2** (`versionCode 9`) for a new release.
- Existing application ID `com.mamacare.uganda` and URL `https://coresys.rhythmoflifeuganda.org` are **unchanged** to preserve app update compatibility and existing WebView features.

## Open and build

1. Extract the ZIP and open `Afri-Mama_Android_v2.2.2` in Android Studio.
2. Allow Gradle to sync and install Android SDK 37 if prompted.
3. Build a debug APK, and verify first launch on both Android 12+ and older Android if available.
4. Use your **existing signing/upload key** to create a signed AAB if submitting as an update on Google Play.

**The ZIP contains Android Studio source code, not an installable APK/AAB.** Build was not run here because the Android SDK is not present in this environment.

**Note:** This correction covers the native Android startup flow. If the remote website contains its own splash/loading page, that must be removed in the website code separately.


Additional update in v2.2.2: simplified startup flow to reduce launch freezes, and splash screen now shows the logo with the Afri-Mama name below it.


## Restored original signing key

The **unmodified original `MAMA.JKS`** file is included in the root project folder. See `SIGNING_GUIDE.md` for signing your AAB/APK with your own original passwords. This version remains **2.2.2**; no code or signing identity has been changed merely by restoring the missing file.
