# This app uses Android's platform WebView API directly.
# No extra keep rules are required for advertising or analytics SDKs.
