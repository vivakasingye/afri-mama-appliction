# Afri-Mama — Android WebView, version 2.2.0

Updated on 2 November 2026 using the provided original Android Studio source project and supplied Afri-Mama logo.

## Updates

- App label: **Afri-Mama** throughout native app resources and connection messages.
- Version: **2.2.0**, `versionCode 8` (previously 2.1.1 / code 7).
- Replaced all launcher icons (normal, round, and adaptive) with the supplied mother-and-child artwork.
- Replaced the old pink/purple illustrated splash with an **icon-only white startup/loading display**. No title, tagline, progress spinner or illustrated background.
- Android 12+ mandatory OS startup transition also uses the icon on white.
- Native progress bar, error view and retry button use pink sampled from the supplied logo on white.
- Core Android WebView, permissions, download/upload handling, and JavaScript/session behaviour remain intact.

## IMPORTANT: Existing identity and start URL preserved

- **Application ID / namespace: `com.mamacare.uganda`**. Changing this ID would create a *new app*, not update an installed app. Its legacy name does NOT affect the displayed app name.
- **Website opened by this app: `https://coresys.rhythmoflifeuganda.org`**. This URL was in the original project and was intentionally NOT guessed or replaced. To point the app at a different Afri-Mama website, change `website_url` in `app/src/main/res/values/strings.xml`, then rebuild.
- The website's own HTML/CSS/theme is remotely hosted. Native app colour updates cannot change that remote site automatically.

## Open in Android Studio

1. Extract ZIP and open the **Afri-Mama_Android_v2.2.0** folder in Android Studio.
2. Let Gradle sync. The project specifies Android compile/target SDK 37 and Java 17 source compatibility. Install the requested SDK when prompted.
3. Select **Build > Build APK(s)** for a locally testable debug build.
4. Test sign-in, navigation, uploads, downloads, keyboard, and permission requests with the production website.
5. Create a **signed Android App Bundle (AAB)** using the **same app-signing/upload key as the existing published app** when uploading an update to Google Play. If you do not have the old signing key (when required), the new archive alone cannot update the published app.

## Security and release note

- No signing keystore or machine-specific `local.properties` is included in this distribution. The original uploaded project contained a `MAMA.JKS` file: **keep the original securely**, and do not share it publicly.
- Previous `app-release.aab` was omitted because it is an older build with the previous branding. It must not be submitted as the updated release.
- This delivery is **edited Android Studio source, not a compiled/signed APK or AAB**. This environment has no Android SDK or emulator to compile and run it; verify on Android Studio before publishing.
